﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ListaTarefas
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Lista de tarefas");
            List<string> tarefas = new List<string>();
            int opcao;
            do
            {
                Console.Clear();
                Console.WriteLine("O que deseja fazer?\n1-Adicionar\n2-Listar\n3-Remover\n4-Sair");
                opcao = int.Parse(Console.ReadLine());

                switch (opcao)
                {
                    case 1:
                        Console.WriteLine("Digite a tarefa: ");
                        tarefas.Add(Console.ReadLine());
                        break;
                    case 2:
                        foreach (var tarefa in tarefas)
                        {
                            Console.WriteLine(tarefa);
                        }
                        break;
                    case 3:
                        if (tarefas.Remove(Console.ReadLine()))
                        {
                            Console.WriteLine("Removendo item...");
                        }
                        else
                        {
                            Console.WriteLine("Não foi possível remover");
                        }
                        break;
                    case 4:
                        Console.WriteLine("Saindo");
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        break;
                }
                Console.ReadKey();
            } while (opcao!=4);
        }
    }
}
