﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BilheteriaEstadio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int maxIngressos = 50000;
            double precoAtual;
            int qtdeIngressos, qtdeTorcedores=0, ingressosVendidos=1, qtdeTorcedoresSemIngresso, qtdeSaldoIngressos=0;

            Console.WriteLine("Informe o preço atual do ingresso: ");
            precoAtual = double.Parse(Console.ReadLine());
            Console.WriteLine("Informe a qtde de ingressos: ");
            qtdeIngressos = int.Parse(Console.ReadLine());

            if (qtdeIngressos > maxIngressos)
            {
                Console.WriteLine("Qtde inválida, máximo de 50000");
            }
            else
            {
                Console.WriteLine("Informe a qtde de torcedores: ");
                qtdeTorcedores = int.Parse(Console.ReadLine());
                if (qtdeTorcedores > qtdeIngressos)
                {
                    qtdeTorcedoresSemIngresso = qtdeTorcedores - qtdeIngressos;
                    qtdeTorcedores = qtdeIngressos;
                    Console.WriteLine("Qtde torcedores sem ingresso: {0}", qtdeTorcedoresSemIngresso);
                }
                else
                {
                    qtdeSaldoIngressos = qtdeIngressos - qtdeTorcedores;
                    Console.WriteLine("Sobrou {0}", qtdeSaldoIngressos);
                }
                while (ingressosVendidos <= qtdeTorcedores)
                {
                    Console.WriteLine("Venda realizada! Saldo de ingressos {0}. Qtde torcedores na fila {1}.", qtdeIngressos-ingressosVendidos, qtdeTorcedores - ingressosVendidos);
                    ingressosVendidos++;
                }
                Console.WriteLine("Total arrecadado R$ {0}", ingressosVendidos-- * precoAtual);
            }
            Console.ReadKey();

        }
    }
}
