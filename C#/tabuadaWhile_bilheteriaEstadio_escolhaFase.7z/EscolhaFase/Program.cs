﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EscolhaFase
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool casaco=true;
            bool armadura=true;
            int pontos=50;
            int fase;
            string codigo;

            Console.WriteLine("Se tiver o código... Insira a seguir ou digite 0 (zero)");
            codigo = Console.ReadLine();

            Console.WriteLine("Escolha o número da Fase:\n 1-Floresta Encantada\n 2-Montanha Congelada\n 3-Fortaleza do Boss");

            fase = Convert.ToInt32(Console.ReadLine());
            if (fase == 1)
            {
                Console.WriteLine("Entrando na Floresta Encantada");
            }
            else if (fase == 2)
            {
                if (casaco == true)
                {
                    Console.WriteLine("Entrando na Montanha Congelada");
                }
                else
                {
                    Console.WriteLine("Você não tem casaco");
                }
            }
            else if (fase == 3)
            {
                if ((pontos >= 100 && armadura) || (codigo == "UNLOCK"))
                {
                    Console.WriteLine("Entrando na Fortaleza do Boss");
                    Thread.Sleep(1000);
                    Console.WriteLine("3 2 1 Já!");
                }
                else
                {
                    if (!armadura)
                    {
                        Console.WriteLine("Você não tem armadura");
                    }
                    else
                    {
                        Console.WriteLine("Você não tem pontos XP");
                    }

                }
            }
            Console.ReadKey();

        }
    }
}
