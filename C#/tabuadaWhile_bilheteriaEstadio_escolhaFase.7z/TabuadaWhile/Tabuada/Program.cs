﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tabuada
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int i=0;
            
            Console.WriteLine("Tabuada");
            Console.WriteLine("Digite um número para ver a tabuada");
            numero = int.Parse(Console.ReadLine());//o Parse dá exceção na tela do sistema o Convert só da exceção

            /*
            Console.WriteLine("O resultado de {0}x0 é: {1}", numero, numero * 0);
            Console.WriteLine("O resultado de {0}x1 é: {1}", numero, numero * 1);
            Console.WriteLine("O resultado de {0}x2 é: {1}", numero, numero * 2);
            Console.WriteLine("O resultado de {0}x3 é: {1}", numero, numero * 3);
            Console.WriteConsoleApp1Line("O resultado de {0}x4 é: {1}", numero, numero * 4);
            Console.WriteLine("O resultado de {0}x5 é: {1}", numero, numero * 5);
            Console.WriteLine("O resultado de {0}x6 é: {1}", numero, numero * 6);
            Console.WriteLine("O resultado de {0}x7 é: {1}", numero, numero * 7);
            Console.WriteLine("O resultado de {0}x8 é: {1}", numero, numero * 8);
            Console.WriteLine("O resultado de {0}x9 é: {1}", numero, numero * 9);
            Console.WriteLine("O resultado de {0}x10 é: {1}", numero, numero * 10);
            */

            while (i <= 10)
            {
                Console.WriteLine("O resultado de {0}x{1} é: {2}", numero, i, numero * i);
                i++;
            }

            Console.ReadKey();
        }
    }
}
