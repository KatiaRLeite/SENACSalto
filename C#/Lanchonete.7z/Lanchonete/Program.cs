﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lanchonete
{
    internal class Program
    {
        static void ExibirMenu()
        {
            Console.WriteLine("Confira nosso cardápio: ");
            Console.WriteLine("1 - Hamburguer (R$ 25,00)");
            Console.WriteLine("2 - Batata Frita (R$ 7,00)");
            Console.WriteLine("3 - Refrigerante (R$ 8,00)");
            Console.WriteLine("4 - Sobremesa (R$ 14,00)");
        }

        static int ObterQuantidade()
        {
            Console.Write("Digite a quantidade: ");
            return int.Parse(Console.ReadLine());
        }

        static double CalcularHamburguer(int qtde)
        {
            return qtde * 25.00;
        }

        static double CalcularBatataFrita(int qtde)
        {
            return qtde * 7.00;
        }

        static double CalcularRefrigerante(int qtde)
        {
            return qtde * 8.00;
        }

        static double CalcularSobremesa(int qtde)
        {
            return qtde * 14.00;
        }

        static void Main(string[] args)
        {
            ExibirMenu();
            Console.Write("Escolha uma opção: ");
            int opcao = int.Parse(Console.ReadLine());

            switch (opcao)
            {
                case 1:
                    int qtd = ObterQuantidade();
                    double valor = CalcularHamburguer(qtd);
                    Console.WriteLine("Total: " + valor + " reais");
                    break;

            }
            Console.ReadKey();
        }
    }
}
