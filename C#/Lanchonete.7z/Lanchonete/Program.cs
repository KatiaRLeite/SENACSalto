﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lanchonete
{
    internal class Program
    {
        static void ExibirMenu()
        {
            Console.WriteLine("Confira nosso cardápio: ");
            Console.WriteLine("1 - Hamburguer (R$ 25,00)");
            Console.WriteLine("2 - Batata Frita (R$ 7,00)");
            Console.WriteLine("3 - Refrigerante (R$ 8,00)");
            Console.WriteLine("4 - Sobremesa (R$ 14,00)");
            Console.WriteLine("5 - Fechar pedido");

        }

        static int ObterQuantidade()
        {
            Console.Write("Digite a quantidade: ");
            return int.Parse(Console.ReadLine());
        }

        static double CalcularHamburguer(int qtde)
        {
            return qtde * 25.00;
        }

        static double CalcularBatataFrita(int qtde)
        {
            return qtde * 7.00;
        }

        static double CalcularRefrigerante(int qtde)
        {
            return qtde * 8.00;
        }

        static double CalcularSobremesa(int qtde)
        {
            return qtde * 14.00;
        }

        static void Main(string[] args)
        {
            int opcao;
            double totGeral;
            int qtd;
            double valor;
            do
            {
                ExibirMenu();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Escolha uma opção: ");
                opcao = int.Parse(Console.ReadLine());
                Console.ForegroundColor = ConsoleColor.White;
                

                switch (opcao)
                {
                    case 1:
                        qtd = ObterQuantidade();
                        valor = CalcularHamburguer(qtd);
                        totGeral = totGeral+valor;
                        Console.WriteLine("Total: " + string.Format("R$ {0:N2}", valor));
                        break;
                    case 2:
                        qtd = ObterQuantidade();
                        valor = CalcularBatataFrita(qtd);
                        Console.WriteLine("Total: " + string.Format("R$ {0:N2}", valor));
                        break;
                    case 3:
                        qtd = ObterQuantidade();
                        valor = CalcularRefrigerante(qtd);
                        Console.WriteLine("Total: " + string.Format("R$ {0:N2}", valor));
                        break;
                    case 4:
                        qtd = ObterQuantidade();
                        valor = CalcularSobremesa(qtd);
                        Console.WriteLine("Total: " + string.Format("R$ {0:N2}", valor));
                        break;
                    default:
                        Console.WriteLine("Opção inválida");
                        break;
                }
            } while (opcao!=5);
            Console.ReadKey();
        }
    }
}
