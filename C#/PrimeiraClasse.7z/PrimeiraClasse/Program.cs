﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeiraClasse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //construtor
            Mensagem msg1 = new Mensagem();
            msg1.textoMensagem = "Bom dia!!";
            msg1.ExibirMensagem();

            Mensagem msg2 = new Mensagem();
            msg2.textoMensagem = "Boa tarde!!";
            msg2.ExibirMensagem();
            Console.ReadKey();
        }
    }
}
