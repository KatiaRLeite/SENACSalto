﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperadoresRelacionais
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             * >
             * <
             * ==
             * >=
             * <=
             * !=
            */
            
            Console.WriteLine("8 > 3 " + (8 > 3));
            Console.WriteLine("8 < 3 " + (8 < 3));
            Console.WriteLine("8 == 3 " + (8 == 3));
            Console.WriteLine("8 >= 3 " + (8 >= 3));
            Console.WriteLine("8 <= 3 " + (8 <= 3));
            Console.WriteLine("8 != 3 " + (8 != 3));

            Console.ReadKey();
        }
    }
}
