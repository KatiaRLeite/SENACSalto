﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeiroCodigo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Resultado da soma entre dois números: " + (2+2));//Escreve uma linha
            Console.WriteLine("Resultado da subtração entre dois números: " + (2-2));//Escreve uma linha
            Console.WriteLine("Resultado da divisão entre dois números: " + (2/2));//Escreve uma linha
            Console.WriteLine("Resultado da módulo entre dois números: " + (2%2));//Escreve uma linha
            Console.ReadKey();//Espera uma entrada do usuário
        }
    }
}
