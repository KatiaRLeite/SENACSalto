﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tabuada
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tabuada do 8");
            Console.WriteLine("8X0=" + (8 * 0));
            Console.WriteLine("8X1=" + (8 * 1));
            Console.WriteLine("8X2=" + (8 * 2));
            Console.WriteLine("8X3=" + (8 * 3));
            Console.WriteLine("8X4=" + (8 * 4));
            Console.WriteLine("8X5=" + (8 * 5));
            Console.WriteLine("8X6=" + (8 * 6));
            Console.WriteLine("8X7=" + (8 * 7));
            Console.WriteLine("8X8=" + (8 * 8));
            Console.WriteLine("8X9=" + (8 * 9));
            Console.WriteLine("8X10=" + (8 * 10));
            Console.ReadKey();

        }
    }
}
