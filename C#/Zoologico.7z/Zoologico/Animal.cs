﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    internal class Animal
    {
        protected string Nome;
        protected int Idade;
        public string Alimento { get; private set; }

        public Animal(string nome, int idade, string alimento)
        {
            if (string.IsNullOrWhiteSpace(nome))
            {
                throw new ArgumentException("O nome do animal não pode ser vazio ou nulo");
            }
            if (idade < 0)
            {
                throw new ArgumentException("Idade não pode ser negativa");
            }
            if (string.IsNullOrWhiteSpace(alimento))
            {
                throw new ArgumentException("O alimento não pode ser vazio ou nulo");
            }
            Nome = nome;
            Idade = idade;
            Alimento = alimento;
        }

        public virtual string Descrever()
        {
            return $"Animal: {Nome}, Idade: {Idade} anos.";
        }
    }
}
