﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    class Reptil : Animal
    {
        private bool Venenoso;

        public Reptil(string nome, int idade, string alimento, bool venenoso)
            :base(nome, idade, alimento)
        {
            Venenoso = venenoso;
        }

        public override string Descrever()
        {
            return base.Descrever()+$"É Venenoso: {(Venenoso?"Sim":"Não")}.";
        }
    }
}
