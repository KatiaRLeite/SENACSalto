﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    class Ave:Animal
    {
        private bool PodeVoar;

        public Ave(string nome, int idade, string alimento, bool podevoar)
            : base(nome, idade, alimento)
        { 
            PodeVoar = podevoar;
        }

        public override string Descrever() 
        { 
            return base.Descrever()+ $"Pode voar: {(PodeVoar?"Sim":"Não")}.";
        }
    }
}
