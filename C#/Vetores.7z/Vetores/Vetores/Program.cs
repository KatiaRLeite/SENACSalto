﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vetores
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //inicialização com valores
            int[] numeros = { 120, 250, 3, 44, 15, 16, 77 };

            //inicialização de um vetor inteiro com 7 posições
            int[] notas = new int[7];
            string[] frutas = { "Maçã", "Laranja", "Banana", "Uva" };

            Console.WriteLine(numeros[3]);

            numeros[3] = 34;

            Console.WriteLine(numeros[3]);

            Console.WriteLine("A primeira fruta é " + frutas[0]);

            Console.ReadKey();
        }
    }
}
