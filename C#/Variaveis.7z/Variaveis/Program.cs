﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variaveis
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string meuNome = "Kátia";
            int idade = 39;
            int ano;
            int anoAtual=DateTime.Now.Year;
            double altura = 1.63;
            string meuCurso = "Técnico em Informática";
            bool residenteSalto = false;

            Console.WriteLine("----------Ficha do Estudante SENAC---------");
            Console.WriteLine("Nome do Estudante: " + meuNome);
            Console.WriteLine("Idade do Estudante: " + idade + " anos");
            Console.WriteLine("Altura do Estudante: " + altura + " metros");
            Console.WriteLine("Curso do Estudante: " + meuCurso);
            Console.WriteLine("Residente em Salto: " + residenteSalto);

            meuNome = "José";
            Console.Clear();
            Console.WriteLine("Digite seu nome para cadastro no SENAC");
            meuNome = Console.ReadLine();
            Console.WriteLine("O nome digitado foi: " + meuNome);

            Console.WriteLine("Digite o ano do seu nascimento");
            ano = Convert.ToInt32(Console.ReadLine());
            idade = anoAtual - ano;
            Console.WriteLine("Sua idade é : " + idade + "anos");

            Console.WriteLine("Digite a sua altura");
            altura = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("A altura digitada foi: " + altura);

            Console.WriteLine("Digite o curso no qual quer se inscrever");
            meuCurso = Console.ReadLine();
            Console.WriteLine("O curso escolhido foi: " + meuCurso);

            Console.WriteLine("Reside em Salto? ");
            residenteSalto = Convert.ToBoolean(Console.ReadLine());
            
            Console.WriteLine("\n----------Ficha do Estudante SENAC---------\n");
            Console.WriteLine("Nome do Estudante: " + meuNome);
            Console.WriteLine("Idade do Estudante: " + idade + " anos");
            Console.WriteLine("Altura do Estudante: " + altura + " metros");
            Console.WriteLine("Curso do Estudante: " + meuCurso);
            Console.WriteLine("Residente em Salto: " + residenteSalto);

            Console.ReadKey();
        }
    }
}
