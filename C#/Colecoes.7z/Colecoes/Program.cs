﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Colecoes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Lista
            List<string> nomes = new List<string>();
            nomes.Add("João");
            nomes.Add("Laura");
            nomes.Add("Maria");
            nomes.Add("Carlos");
            nomes.Add("Leticia");
            nomes.Add("Laura");
            nomes.Add("Margareth");
            foreach (var s in nomes)
            {
                Console.WriteLine(s);
            }
            Console.ReadKey();

            //Colecao
            HashSet<int> numeros = new HashSet<int>();
            numeros.Add(10);
            numeros.Add(20);
            numeros.Add(10);//não adiciona repetido
            numeros.Add(20);
            foreach (var numero in numeros)
            {
                Console.WriteLine(numero);
            }
            Console.ReadKey();

            //Mapa
            Dictionary<string,int> idades = new Dictionary<string,int>();
            idades.Add("Maria", 35);
            idades.Add("Laura", 25);
            Console.WriteLine("Idades");
            foreach (var par in idades)
            {
                Console.WriteLine($"Nome: {par.Key} Idade: {par.Value}");
            }
            Console.ReadKey();
        }
    }
}
