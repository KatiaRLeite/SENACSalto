﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JogoAventura
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string opcao;
            string displayEspada = "Espada";
            string displaySemEspada = "Sem Espada";

            string displayEscudo = "Escudo";
            string displaySemEscudo = "Sem Escudo";

            int vida = 100;
            bool espada = false; 
            bool escudo = false;

            Console.WriteLine("\\,,,,,/" +
                              "\n(.°v°.)" +
                              "\n/ (_) \\" +
                              "\n _^ ^_ ");

            Console.WriteLine("                               Vida " + vida+"\n");
            Console.WriteLine("Você encontra uma espada, você decide: \ncoletar(C) ou não(N)");
            opcao = Console.ReadLine();
            if (opcao == "C")
            {
                espada = true;
            }
            else
            {
                if (opcao == "N")
                {
                    espada = false;
                }
                else 
                {
                    Console.WriteLine("Opção inválida");
                }
            }
            Console.WriteLine("Você encontra um escudo, você decide: \ncoletar(C) ou não(N)");
            opcao = Console.ReadLine();
            if (opcao == "C")
            {
                escudo = true;
            }
            else
            {
                if (opcao == "N")
                {
                    escudo = false;
                }
                else
                {
                    Console.WriteLine("Opção inválida");
                }
            }

            Console.WriteLine("Um monstro surge à sua frente, você decide: \natacar(A), defender(D) ou fugir(F) ?");
            opcao = Console.ReadLine();
            if (opcao == "A")
            {
                Console.Clear();
                if (espada)
                {
                    Console.WriteLine("                               Vida: " + vida + "\n");
                    if (espada) 
                    {
                        Console.WriteLine("                               Inventario: "+displayEspada + "\n");
                    } 
                    else
                    {
                        Console.WriteLine("                               Inventario: "+displaySemEspada + "\n");
                    }
                    if (escudo)
                    {
                        Console.WriteLine("                               Inventario: " + displayEscudo + "\n");
                    }
                    else
                    {
                        Console.WriteLine("                               Inventario: " + displaySemEscudo + "\n");
                    }
                    Console.WriteLine("Você atacou o monstro com a espada e não sofreu dano.");
                }
                else
                {
                    vida -= 30;
                    Console.WriteLine("                               Vida " + vida + "\n");
                    if (espada)
                    {
                        Console.WriteLine("                               Inventario: " + displayEspada + "\n");
                    }
                    else
                    {
                        Console.WriteLine("                               Inventario: " + displaySemEspada + "\n");
                    }
                    if (escudo)
                    {
                        Console.WriteLine("                               Inventario: " + displayEscudo + "\n");
                    }
                    else
                    {
                        Console.WriteLine("                               Inventario: " + displaySemEscudo + "\n");
                    }
                    Console.WriteLine("Você atacou o monstro e sofreu um dano de 30 pontos.");
                }

            }
            else
            {
                if (opcao == "F")
                {
                    Console.Clear();
                    Console.WriteLine("                               Vida " + vida + "\n");
                    if (espada)
                    {
                        Console.WriteLine("                               Inventario: " + displayEspada + "\n");
                    }
                    else
                    {
                        Console.WriteLine("                               Inventario: " + displaySemEspada + "\n");
                    }
                    if (escudo)
                    {
                        Console.WriteLine("                               Inventario: " + displayEscudo + "\n");
                    }
                    else
                    {
                        Console.WriteLine("                               Inventario: " + displaySemEscudo + "\n");
                    }
                    Console.WriteLine("Você fugiu! Não tem vergonha? Pelo menos não sofreu dano!");
                }
                else if (opcao == "D")
                {
                    if (escudo)
                    {
                        vida -= 10;
                    }
                    else
                    {
                        vida -= 50;
                    }
                    Console.Clear();
                    Console.WriteLine("                               Vida " + vida + "\n");
                    if (espada)
                    {
                        Console.WriteLine("                               Inventario: " + displayEspada + "\n");
                    }
                    else
                    {
                        Console.WriteLine("                               Inventario: " + displaySemEspada + "\n");
                    }
                    if (escudo)
                    {
                        Console.WriteLine("                               Inventario: " + displayEscudo + "\n");
                    }
                    else
                    {
                        Console.WriteLine("                               Inventario: " + displaySemEscudo + "\n");
                    }
                    Console.WriteLine("Você defendeu e sofreu um dano!");
                }
                else
                {
                    Console.WriteLine("Opção inválida");
                }
                
            }
            Console.ReadKey();
        }
    }
}
