﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Condicionais
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //bool chovendo = false;
            int n1;
            int n2;

            Console.WriteLine("Digite n1 ");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Digite n2 ");
            n2 = Convert.ToInt32(Console.ReadLine());

            if (n1>=n2)
            {
                if(n1==n2)
                {
                    Console.WriteLine("n1=n2");
                }
                else
                {
                    Console.WriteLine("n1>n2");
                }
            }
            else
            {
                Console.WriteLine("n2>n1");
            }
            Console.ReadKey();
        }
    }
}
