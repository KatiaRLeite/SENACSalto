﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class frmTelaLogin : Form
    {
        public frmTelaLogin()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if (textboxEmail.Text.Equals("katiarleite@gmail.com") &&
                textboxSenha.Text.Equals("123"))
            {
                var principal = new frmPrincipal();
                principal.Show();
                this.Visible = false;
            }
            else
            {
                MessageBox.Show("Email ou senha incorretos",
                    "Falha no login kk", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textboxSenha.Text = "";
                textboxEmail.Focus();
            }
        }
    }
}
