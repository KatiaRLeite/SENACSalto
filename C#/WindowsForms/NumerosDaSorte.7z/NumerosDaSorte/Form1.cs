﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NumerosDaSorte
{
    public partial class NumerosDaSorte : Form
    {
        public NumerosDaSorte()
        {
            InitializeComponent();
        }

        private List<int> GerarNumeros()
        { 
            Random random = new Random();
            HashSet<int> numerosSorteados = new HashSet<int>();
            while (numerosSorteados.Count < 6)
            {
                int numero = random.Next(1, 60);
                numerosSorteados.Add(numero);
            }
            return numerosSorteados.ToList();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            List<int> numeros = GerarNumeros();
            //separa os itens de uma lista por um caracter no caso hífen
            lblSorteados.Text = string.Join(" - ", numeros);
        }
    }
}
