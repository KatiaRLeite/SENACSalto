﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnOff
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAlterna_Click(object sender, EventArgs e)
        {
            if (lblEstado.Text == "Desligado")
            {
                timerDesligar.Enabled = true;
                lblEstado.Text = "Ligado";
                this.BackColor = Color.Green;
                System.Media.SystemSounds.Beep.Play();
            }
            else
            {
                timerDesligar.Enabled = false;
                lblEstado.Text = "Desligado";
                this.BackColor = Color.Red;
                System.Media.SystemSounds.Beep.Play();

            }


        }

        private void timerDesligar_Tick(object sender, EventArgs e)
        {
            lblEstado.Text = "Desligado";
            this.BackColor = Color.Red;
            timerDesligar.Enabled = false;
        }
    }
}
