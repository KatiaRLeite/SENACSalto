﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContaBancaria
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Conta conta = new Conta("Jeferson José Jeremias", 10000.00m);
            Console.WriteLine($"Bem vindo(a), {conta.Titular}");
            conta.ExibirSaldo();
            int escolha;
            do
            {
                ExibirMenu();
                escolha = int.Parse(Console.ReadLine());
                switch (escolha)
                {
                    case 1:
                        Console.WriteLine("Digite o valor do depósito");
                        decimal valorDepos = Convert.ToDecimal(Console.ReadLine());
                        conta.Depositar(valorDepos);
                        break;
                    case 2:
                        Console.Write("Digite o valor do saque");
                        decimal valorSaque = Convert.ToDecimal(Console.ReadLine());
                        conta.Sacar(valorSaque);
                        break;
                    case 3:
                        conta.ExibirSaldo();
                        break;
                    case 4:
                        Console.Clear();
                        Console.WriteLine($"Bem vindo(a), {conta.Titular}");
                        break;
                    case 5:
                        Console.WriteLine("Obrigada por usar o POO_Bank");
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        break;
                }
            } while (escolha != 5);
            Console.ReadKey();
        }

        public static void ExibirMenu() 
        {
            Console.WriteLine("Informe qual operação deseja: " +
                            "\n1-Depositar " +
                            "\n2-Sacar " +
                            "\n3-Exibir Saldo " +
                            "\n4-Reiniciar " +
                            "\n5-Sair ");
        }
    }
}
