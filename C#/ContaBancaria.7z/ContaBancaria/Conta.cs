﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContaBancaria
{
    internal class Conta
    {
        public string Titular { get; private set; }
        private decimal _saldo;

        public Conta(string titular, decimal saldoInicial)
        {
            Titular = titular;
            _saldo = saldoInicial;
        }

        public void ExibirSaldo()
        {
            Console.WriteLine($"\nO saldo é de R$ {_saldo:F2}");
        }

        public void Depositar(decimal valor)
        {
            _saldo += valor;
            ExibirSaldo();
        }

        public void Sacar(decimal valor)
        {
            if (valor <= _saldo)
            {
                _saldo -= valor;
                Console.WriteLine($"\nSaque de {valor:F2} realizado com sucesso");
            }
            else
            {
                Console.WriteLine("\nSaldo insuficiente");
            }
            ExibirSaldo();
        }
    }
}
