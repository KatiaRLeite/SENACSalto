﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsumoCombustivel
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int combustivel = 100; //Qtde inicial
            int consumo = 5; //consumo a cada ciclo
            int capacidadeReserva = 20; //nível de alerta para abastecer
            int capacidadeTanque = 100; //nível de alerta para abastecer


            Console.WriteLine("Você entrou no carro. Digite acelerar para começar a dirigir:");
            string escolha = Console.ReadLine().ToLower();
            if (escolha == "acelerar")
            {
                Console.WriteLine("O carro começou a se mover");
                while (combustivel > 0)
                {
                    //diminui o combustível
                    combustivel -= consumo;
                    Console.Clear();

                    Console.WriteLine("Carro em movimento \n Digite (p) para parar");
                    Console.WriteLine("Carro em movimento \n Digite (a) para abastecer");

                    Console.WriteLine("\nCombustível restante" + combustivel);
                    //Verifica se o combustível está no nível de reserva
                    if (combustivel <= capacidadeReserva && combustivel > 0)
                    {
                        Console.WriteLine("Alerta: Combustível esgotando");
                        Console.Beep(5000, 1000); //HZ e Ms
                    }
                    if (combustivel <= 0)
                    {
                        Console.WriteLine("O combustível acabou! O carro parou...");
                        break;
                    }
                    //Pausa para simular o consumo contínuo
                    Thread.Sleep(500);

                    //Verifica se alguma tecla foi pressionada
                    if (Console.KeyAvailable)
                    { 
                        char tecla = Console.ReadKey(true).KeyChar; //o true não mostra a tecla pressionada na tela
                        if (char.ToUpper(tecla) == 'P')
                        {
                            Console.WriteLine("\n Você parou o carro\nSimulação encerrada");
                            Console.WriteLine("Combustível restante: "+combustivel);
                            break;
                        }
                        else if (char.ToUpper(tecla) == 'A')
                        {
                            if ((combustivel + 50) <= capacidadeTanque)
                            {
                                Console.WriteLine("Você parou para abastecer, aguarde...");
                                Thread.Sleep(1000);
                                Console.WriteLine("Abastecido!");
                                combustivel += 50;
                                Console.WriteLine("Combustível restante: " + combustivel);
                                Thread.Sleep(1500);
                            }
                            else
                            {
                                Console.WriteLine("Você parou para abastecer, aguarde...");
                                Thread.Sleep(1500);
                                Console.WriteLine("Tanque completado!");
                                combustivel = 100;
                                Console.WriteLine("Combustível restante: " + combustivel);
                                Thread.Sleep(1500);
                            }
                        }

                    }
                }
            }
            else
            {
                Console.WriteLine("Opção invalida. Simulação encerrada");
            }

            Console.WriteLine("Fim Simulação");

            Console.ReadKey();
        }
    }
}
