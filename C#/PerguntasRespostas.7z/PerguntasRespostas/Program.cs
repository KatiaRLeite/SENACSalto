﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerguntasRespostas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] perguntas =
            {
                "1) Qual é o elemento químico representado pelo símbolo 'O'?",
                "2) Qual é o país mais populoso do mundo?",
                "3) Qual é o animal nacional da Austrália?",
                "4) Quantos dias são necessários para a Terra orbitar o sol?",
                "5) Qual é a série de livros mais vendida do século 21? ",
                "6) Qual é a flor nacional do Japão?"
            };
            string[] respostas =
            {
                "Oxigênio",
                "Índia",
                "Canguru",
                "365",
                "Harry Potter",
                "Cerejeira"
            };

            string resposta="";
            string jogarNovamente = "";

            int acertos = 0;

            while (true)
            {
                Console.WriteLine("Perguntas e respostas conhecimentos gerais, digite sair");
                for (int i = 0; i < perguntas.Length; i++)
                {
                    Console.WriteLine(perguntas[i]);
                    resposta = Console.ReadLine();
                    
                    if (resposta.Equals(respostas[i], StringComparison.OrdinalIgnoreCase))
                    {
                        Console.WriteLine("Acertou!");
                        acertos++;
                    }
                    else
                    {
                        Console.WriteLine("Errou!");
                    }

                }
                if (acertos == 6)
                {
                    Console.WriteLine("Você acertou tudo, parabéns!!!");
                    break;
                }
                else
                {
                    Console.WriteLine("Você acertou " + Convert.ToString(acertos) + " de " + perguntas.Length + " perguntas");
                    Console.WriteLine("Deseja jogar novamente? (S/N)");
                    jogarNovamente = Console.ReadLine();
                    if (jogarNovamente.ToUpper() == "N")
                    {
                        break;
                    }
                    else
                    {
                        Console.Clear();
                    }
                }
            }
            
            Console.WriteLine("Obrigada por jogar");
            Console.ReadKey();
        }
        
        
    }
}
