﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VetorNumeros
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numeros = new int[5];
            int maior = 0;

            string[] cores = { "Vermelho", "Verde", "Azul", "Amarelo" };

            for (int i = 0; i < cores.Length; i++)
            {
                Console.WriteLine("Cores "+(i+1)+" "+cores[i]);
            }

            //Console.WriteLine("Informe 5 números inteiros positivos:");
            //for (int i = 0; i < 5; i++)
            //{
            //    Console.Write("\nDigite o número " + (i+1) +" :");
            //    numeros[i] = int.Parse(Console.ReadLine());
            //    if (i == 0)
            //    {
            //        maior = numeros[i];
            //    }
            //    if (numeros[i] > maior)
            //    {
            //        maior = numeros[i];
            //    }
            //}
            //for (int i = 0; i < 5; i++)
            //{
            //    Console.Write("\nO número é: " + numeros[i]);
            //}
            //Console.WriteLine("\nO maior número é: " + maior);
            Console.ReadKey();
        }
    }
}
