﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int idade;
            Console.Write("Informe a sua idade: ");
            idade = Convert.ToInt32(Console.ReadLine());
            if (idade >= 60)
            {
                Console.WriteLine("Usuário Idoso");
            }
            else if (idade >= 18)
            {
                Console.WriteLine("Usuário Adulto");
            }
            else if (idade >= 12)
            {
                Console.WriteLine("Usuário Adolescente");
            }
            else
            {
                Console.WriteLine("Usuário é uma criança");
            }



            Console.ReadKey();
        }
    }
}
